---
name: mfc-learning-screen
description: Project guide and feature-adding agent for the Montfort Care "Presence in Singapore" interactive map (the repo unidotcon1/interactive_map, plain HTML/CSS/JS, no build step). Use it whenever the user wants to add, change, fix or review anything on this website: a new region, service, Goodlife centre or detail page, a new dot, colour or theme change, a Bloop (the 3D whale mascot) behaviour, the hologram, the sideways-scrolling detail pages, the video, contact details, the tour, tests, README or a PR. Use it even when the request is short or vague ("make bloop do X", "add a page for Y", "the map looks off") because it holds the architecture, the conventions, the git and test workflow and a prompting guide, so you can act with the fewest clarifying questions.
---

# mfc-learning-screen: add features to the Montfort Care interactive map

This skill is your memory of the project. Read it, then the one reference you need, then act. The
user owns the design; your job is to turn a short request into a tested, reviewable change.

## What the site is
An interactive "Presence in Singapore" map for Montfort Care. A tilted 3D island is split into three
teal regions (North, East, South). Each region has one dot per service. Pressing a dot zooms in, plays a
shock, beam and 3D hologram, and slides in a **detail page** that scrolls **sideways** (a row of
panels). Seniors dots open the **Goodlife** pages. Bloop, a WebGL whale, lives on the Mental Health
page. No build, no framework: open `index.html`. The only dev dependency is Playwright.

## First five minutes of any task
1. `git status` and `git log --oneline -3`; make sure you are on a fresh feature branch from the latest `main` (see `references/workflow.md`).
2. Read the matching reference below. Do not read the whole repo.
3. Decide with the **prompting guide** (`references/prompting-guide.md`) whether to ask anything. Default: do not ask, pick the sensible option, say what you picked in one line.
4. Make the change, look at it in screenshots at 1920×1080 and 390×844, run the tests, commit, push, open a PR, stop and wait for the user to merge.

## Which reference to read
| The request is about | Read |
| --- | --- |
| Where things are, how the camera, regions, dots, hologram, rail and Bloop work | `references/architecture.md` |
| Step-by-step recipes (new region, service, Goodlife centre or page, panel, Bloop trick, colour, tour step) | `references/recipes.md` |
| Branches, tests, PRs, merge rules, what went wrong before | `references/workflow.md` |
| Turning a vague wish into a precise change; what to ask; what to assume | `references/prompting-guide.md` |
| Brand colours, fonts, content rules, contact data | `references/brand-and-content.md` |

## Rules that save the most time (the why is in the references)
- **The inline map in `index.html` is generated.** Never hand-edit between `<!-- MAP:START -->` and `<!-- MAP:END -->`; change `tools/build_map.py` and run it (it needs the unzipped deck dir containing `ppt/slides/slide10.xml`).
- **Never invent contact details or copy.** Contacts come from https://montfortcare.org.sg/contact-us/ and descriptions from the Eldercare page; put them in `data/`, not in code.
- **No new dependencies, no build step.** Everything must open from `index.html` and work offline (the video loads only on click).
- **Two tests, desktop only:** `npm run test:small` (about 15 s, for small changes) and `npm run test:big` (minutes, for big changes; run in the background and poll the output file). Phone is off by default (`PHONE=1`). Keep both green.
- **One phase per branch; merge on GitHub; never merge `main` into a branch; do not stack PRs.** A squash merge once silently reverted a feature.
- **Keep answers short.** Show screenshots, say what changed in a few lines, and do not explain preview steps unless asked.
- **Agents:** use a worktree agent only for work on a disjoint set of files (give it the file list, say "do not push"), and log it in `docs/skills-used.md`.

## Definition of done
Feature visible and screenshotted on desktop (and phone if the layout changed); the right test passes (add or update a check for the new behaviour in `tests/`); `README.md` section updated; `docs/skills-used.md` updated if a skill or agent was used; `docs/memory.md` refreshed if files or dependencies changed; committed with the project's two attribution lines; PR opened with the repo's description style; user told in plain words what to look at.
