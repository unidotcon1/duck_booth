# Recipes

Each recipe ends with: screenshot (desktop; phone if layout changed) → add a check in the right test file → README → `npm test` → commit → PR.

## Change a colour or theme
- Sea / land / coast / area-off: CSS variables at the top of `styles.css`; slab sides and shadow tones: `SLAB_TONES` in `app.js`.
- Region colours: `REGIONS[...]["colour"]` in `tools/build_map.py`, then regenerate the map (never edit the SVG by hand).
- Service page colours: `theme` in `data/services.js`. Goodlife colours: `pages[...]` in `data/goodlife.js` and the page's CSS classes.
- Brand palette: see `brand-and-content.md`. Dark text on dark backgrounds is the usual mistake: check the back button and map header (they are white on the navy sea).

## Add or change a Goodlife centre
Edit `data/goodlife.js` → `centres[studio|makan|athome|hub]` with `{name, region, addr[], phone, email}`. Copy from the Contact Us page; never invent. The cards, counts and the whole-of-Goodlife page update themselves; update the counts expected in `tests/zoom.test.js` (`all.cards`).

## Add a new Goodlife page or change which opens for a region
`data/goodlife.js`: add a `pages.<key>` entry and `defaultPage[region]`. `goodlife.js`: add `PAGES.<key>(region)` returning `panel(...)` calls, and add the key to `window.goodlife.pages` and `names`. Styles go in the `/* Goodlife pages */` block of `styles.css`.

## Add a panel to any detail page
Generic pages: in `fillDetail` (`app.js`) add `panel(title, bg, innerHTML)`. Goodlife: add `panel(title, bg, textColour, inner, {wide, cls})` in the page function. Keep content to one idea per panel; `rail.js` shrinks overflow, but below ~0.6 scale text gets small, so split the panel instead. Use `wide` only for horizontal card flows (`.gl-flow` uses `grid-auto-flow: column`).

## Add a service (a new dot kind)
1. `data/services.js`: copy a service object (legend, dot colour, name, logo, theme, hero, programmes).
2. `tools/build_map.py`: add the service to `SERVICE_NAMES`, the legend and the region's service list; regenerate.
3. Check the tour text and the "13 dots" and legend counts in the tests.

## Add a region
`REGIONS` in `build_map.py` (name, colour, places, per-service counts); regenerate; update tour text, counts (`"3 regions · 41 branches"`) and tests. Regions must keep a visible gap and must not overlap the legend.

## Add a Bloop trick
`bloop.js`: add the type to `DURATION`, add its pose in `trickPose()` (return values 0..1 for `squint, happy, blush, jump, fin, shade, shine, sway, spout`), map a press area in `partAt()`, and extend the shader only if a new look needs a uniform (add to the `U` list and `draw()`). Keep arms in `toArm` space. Add a check in the Bloop part of the tests using `window.bloop.start(type)` and `pose`.

## Add a tour step
`STEPS` in `app.js` (`level`: map, select (East's list) or detail (an East Goodlife page); `target`: the element to spotlight; `text`: Bloop's line; optional `face`, `self`, `splash`, `show`, `ask` (the user taps it themselves), `pick`, `swipe`, `bye`, `wiggle` 1 or 2 (he wiggles while he talks)). Bloop talks, so write each step as one short line. The tour test in `tests/zoom.test.js` expects the step count (14) and the route: update it.

## Change the video
Compress first (ffmpeg, 480p, no audio, about 3 MB): `ffmpeg -i in.mp4 -vf scale=-2:480,fps=24 -c:v libx264 -crf 34 -movflags +faststart -an assets/video/goodlife-studio.mp4`, add a poster jpg, and edit `video` in `data/goodlife.js`. It must stay lazy: no download before its panel is shown.

## Add pictures to a detail page
Add `{src, alt, caption}` to `data/gallery.js` (`service.<key>` or `goodlife.<page>`). Photos of 1600 px or wider can use `bleed: true` to fill the panel. Save images into `assets/` as webp. The Montfort Care site refuses automatic image downloads (403), so ask the user to save the pictures and upload them; do not try to bypass the block.

## Add contact details
`data/contacts.js` (keys: place id, service, branch number) or `data/goodlife.js`. Source: Contact Us page only.
