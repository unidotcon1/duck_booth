# Architecture (where things live)

## Files
| File | Role |
| --- | --- |
| `index.html` | Page shell; the map SVG is **generated** between `MAP:START`/`MAP:END`; also the detail pane (`#detail`, `#detail-body` rail, `#rail-nav`), hologram (`#holo`, `#shock`), tour, toolbar |
| `app.js` | Everything interactive: camera, hover/select, dots, detail pages, hologram timing, tour, `window.mapView` test hook |
| `rail.js` | The sideways rail of panels in every detail page (wheel, drag, arrows, dots, background blend, fit-to-height) |
| `goodlife.js` + `data/goodlife.js` | The Goodlife pages (Studio, Makan, At Home, All) and their content and contacts |
| `bloop.js` | Bloop, the 3D whale: WebGL raymarcher, tricks, cursor following; `window.bloop` test hook |
| `holo.js` | The 3D shophouse hologram on a canvas; `window.holoHouse` hook |
| `data/services.js` | Copy and images for the six service pages (from the onboarding deck) |
| `data/contacts.js` | Branch contacts keyed by place, service, branch (mostly empty: not in the deck) |
| `styles.css` | All styles (CSS variables at the top: sea, land, brand colours) |
| `tools/build_map.py` | Generates the map SVG: regions, shapes, dots, labels |
| `tests/smoke.test.js` | The small test (`npm run test:small`, about 15 s) |
| `tests/zoom.test.js`, `tests/bloop.test.js` | The big tests (`npm run test:big`) |
| `assets/` | Images and logos from the deck |
| `docs/` | `skills-used.md`, `memory.md` |

## Map and camera
- One eased progress value (ease-in-out cubic, 1 s) drives the camera centre, log-space half-width, tilt and the detail panel together, so a zoom never reverses. Moves run as Web Animations on compositor layers; the map layers are drawn once per move (at most 2 draws) and redrawn sharp on arrival. Keep it that way: do not redraw per frame.
- Regions (`REGIONS` in `build_map.py`): North, East, South in three shades of teal, made from the nearest-branch field with noise, clipped to the mainland. 13 dots in total (one per service per region). Dots are a **single row, touching, no plate**; when one is enlarged its neighbours step aside (`layoutDots`).
- North and East reach further on the right of the map (`EXTRA_REACH`, from `EXTRA_FROM_X`) so no stray bit of island is left grey between them; the far west stays grey on purpose.
- Each region's chip (dot row + name) is placed by `best_chip_spot()` in `build_map.py`: the point inside the region AND the mainland with the most clearance for the whole chip box. Do not hand-place chips; the smoke test checks they sit fully inside.
- Pressing a region (selected) adds `.is-listed` (dots and name move up 62 units) and shows `#place-list` (HTML card below the name, built from each dot's `data-branches`). Pressing a legend entry opens that service (`legendHit` in `app.js` finds the entry from where the legend's pieces are on screen); Goodlife opens `forceGl = "all"`.
- Hover or select raises a region (`#lift`), greys the others (`--area-off`) but keeps their names and dots dimmed; leaving floats it back down (`.is-settling`). Selected beats hover. Touch ignores hover. Phones zoom to the selected region.
- Levels: `map` and `centre`. `body.dataset.level`, `data-moving`; `body.has-back` slides the title aside for the back button.

## Detail pages (the sideways rail)
- Moving along the rail (scrollLeft > 60px) sets `body.dataset.cover = "1"`: `#detail` widens to the full window and covers the island (the back button sits outside the stage so it stays on top). Picture panels (`gallery.js`, data in `data/gallery.js`) follow the content, with parallax (`--shift`). A slider (`.rail-slider`) in the nav moves along the rail.
- `#detail-body` is `.rail`: a flex row of `<section class="panel" data-title data-bg><div class="pin">…</div></section>`. `rail.js` blends the rail background between panels' `data-bg`, scales each `.pin` down so it fits the height (no vertical scroll anywhere), and maps the vertical wheel to sideways.
- Generic service pages: panels = Overview (deck hero), What we do (programmes), Contact us (branches in that region).
- Seniors: `goodlife.js` returns panels for Studio / Makan / At Home / All. A drop-down `#gl-select` at the top right switches. Default page per region is `defaultPage` in `data/goodlife.js` (north: At Home, south: Studio, east: Makan).
- The Studio video is a local, compressed mp4 (`assets/video/`): not downloaded until its panel is on screen, then autoplays muted and loops (IntersectionObserver in `goodlife.js`); reduced motion waits for a press.

## Hologram
Scenes in `holo.js`: `house()` (default) and `entrance()` (East Anti-Violence: the Child Protection Specialist Centre wall, shutter door and sign). `showHolo` picks one with `holoHouse.use(...)`; add a scene by writing another function that returns `{name, lines, faces, HR, rings, slice(h), text?, centres()}`.
After the zoom lands: a dark/light **shock** over the map pane, then a beam from the pressed dot and a 3D shophouse building up (entrance 45° left). It takes the **pressed dot's colour**. No replay when switching service inside the same region (`holoRegion`). The map behind it is darkened. Reduced motion: still house.

## Bloop
Only on the Mental Health page, and as the tour's guide on any page (`enterGuide`, `exitGuide`, `guideFace`, `guideLook` in `window.bloop`: splash entrance, happy `> w <` face, looks at the spotlight, above the tour's dim layer). He follows the cursor (head, body turn, slide), waves on load, and reacts to where you press: belly jumps, face squints, lantern shines (sunglasses first), spout sprays while he squints and smiles. His arms barely follow body yaw (`toArm`) so they keep their height and size. The canvas is drawn 2× his box (`OVER`) so his light is never cut off. See the Bloop recipe for sleep, rub and walk if present.

## Test hooks
`window.mapView` (`level, place, service, glPage, lifted, holo, camera, draws, tourStep`), `window.bloop`, `window.holoHouse`, `window.rail` (`index, count, goto, reset`), `window.goodlife`, `window.SERVICES`, `window.GOODLIFE`.
