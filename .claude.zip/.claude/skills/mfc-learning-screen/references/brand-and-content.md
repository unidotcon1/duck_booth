# Brand and content

## Palette (from the Montfort Care deck)
- Primary navy `#193973` (tints for text and bands); deep navy for the sea `#0f2245`.
- Secondary: teal `#00A79D`, lime green `#8DC63F`.
- Accents: orange `#F7941D`, red `#EF3851`, sky blue `#44A3DB`.
- Service dot colours: Families orange, Anti-Violence purple, Caregiving red, Mental Health blue, Seniors green, Corporate Service white.
- Regions: three teal shades (`#0a6d78` North; `#0f8f94` East; `#47c2b1` South (North is the darkest, then East, then South)). The map is a dark navy sea with blue-grey land (`#7588ab`), so header text, the logo and the back button are white.
- Goodlife: Studio teal, Makan orange, At Home blue.

## Fonts and tone
**Bariol is the only typeface**, for every word (UI, headlines, map labels, tour). It is self-hosted in `assets/fonts/` (regular 400, bold 700, italic 400) and set through the `--label-font`, `--body-font` and `--heavy-font` variables in `styles.css`, with `font-synthesis: none`. Use weight 400 or 700 only; do not add other families or heavier weights (they would be faked). Text baked into deck images cannot change. Plain, warm, short sentences; seniors and caregivers are the audience. Use the deck's wording; do not rewrite claims.

## Content sources
- Deck (`onboard_lq.pptx`): slide 10 is the map artwork; slides 8–17 are the service pages (copy and images in `data/services.js`, `assets/`).
- https://montfortcare.org.sg/services/eldercare/ : Goodlife descriptions.
- https://montfortcare.org.sg/contact-us/ : every address, phone and email. **Never invent contact details.**
- The Goodlife Studio page on the site is only a one-page flyer. The Studio film is `assets/video/goodlife-studio.mp4` (from the user's upload, compressed).
- The site's image files return 403 to automatic downloads: ask the user for pictures instead of working around it.

## Accessibility baseline
Keyboard: Tab to a region, Enter selects, Tab between dots, Enter opens; Escape and the back button step out; arrow keys move along the rail. Reduced motion: no flash, no build-up, still Bloop, jumps instead of eased moves. Every control has an accessible name; focus is visible.
