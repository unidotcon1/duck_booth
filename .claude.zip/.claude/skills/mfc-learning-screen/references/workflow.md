# Git, tests and PR workflow (and the mistakes behind the rules)

## Branches and PRs
1. `git fetch origin && git checkout main && git pull --ff-only origin main && git checkout -b feature/<short-name>`.
2. Work, test, then commit and push (`git push -u origin <branch>`). Commit messages end with the two attribution lines given by the session reminder. Push only the designated branch.
3. Open the PR into `main` (`mcp__github__create_pull_request`), description in the repo's style: What / Tests / Please check, ending with the attribution line. Do not merge it yourself.
4. Wait for the user to say "merged". Then start the next phase from the new `main`.
5. If the user merged and then reports old behaviour: they have a stale checkout or cached page. Tell them: `git fetch origin --prune`, `git checkout main`, `git reset --hard origin/main`, hard refresh (Ctrl+Shift+R). First compare `origin/main` with your tested branch (`git diff`): if empty, main is right.

## What went wrong before (so it does not again)
- Squash-merging stacked PRs corrupted `tests/zoom.test.js` and dropped last commits. Do not stack PRs.
- The user merged `main` into a feature branch and parts of the 3D hologram were silently reverted (`app.js` referenced a variable that no longer existed: console error, broken back button). Ask users to merge PRs on GitHub only, and run the tests after any merge.
- A generated file was hand-edited and duplicated by a bad slice. Always regenerate; when patching files with Python, search from a start index.

## Tests (two kinds; desktop only by default)
- Once: `npm install && npx playwright install chromium`.
- **Small test, about 15 seconds: `npm run test:small`** (also `npm test`). `tests/smoke.test.js`: map and dots, fonts, a Families page (sideways rail, no vertical scroll), Goodlife drop-down, Bloop on Mental Health, hologram, back, no console errors. Use it for small changes: wording, data, a colour, one panel's content.
- **Big test, several minutes: `npm run test:big`** = the small test + `tests/zoom.test.js` (camera, hover, select, hologram, tour, keyboard, Goodlife, reduced-motion run through every dot) + `tests/bloop.test.js` (sleep, petting, walking, tricks). Use it for big changes: camera or layout, a new page or panel type, animation, Bloop, the hologram, shared CSS or JS structure, and before opening a PR that changes several things.
- Phone (390×844 touch) is off by default. `PHONE=1 npm run test:big` adds it; take phone screenshots by hand when a layout changes.
- `ONLY=goodlife node tests/zoom.test.js` runs just the Goodlife checks.
- Run the big test in the background: `(npm run test:big > /tmp/t.out 2>&1; echo finished >> /tmp/t.out) &`, then check the file. Never chain sleeps.
- WebGL in headless Chromium needs `--use-gl=swiftshader --enable-unsafe-swiftshader` for ad-hoc scripts.
- A check that samples frames can flake on a slow machine: prefer checking final state, animation keyframes, or the peak over several samples.
- Tests must not touch the network: YouTube requests are routed to abort and must be zero before the play button is pressed.
- When you add a feature, add its check to the small test only if it is a basic "is it still alive" check; put detailed checks in the big tests.

## Screenshots
Use Playwright, `deviceScaleFactor: 1` for your own checks, 2 for pictures the user will see. Look at them. Send the user the useful ones.

## Time and tokens
Long outputs hide the one failing line: filter test output with `grep -v "^  ok"`. Do not re-read big files you already edited; use targeted `sed -n` ranges.
