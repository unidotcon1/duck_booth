# Prompting guide: understand the request in the fewest prompts

## For the agent: how to read a request
1. **Find the object, the change and the trigger.** Most requests are "[thing] should [behaviour] when [trigger]". Map them to the architecture: thing = region, dot, hologram, Bloop, rail panel, Goodlife page, header, tour. If the trigger is missing, use the most natural one (hover for the map, press for Bloop, load for pages).
2. **Assume, do not ask,** when a sensible default exists. Decide, build, and write one line: "I made X do Y; say if you meant Z." Ask only when a wrong guess is expensive: it changes data the user owns (contacts, copy), deletes work, changes the git history, or there are two incompatible readings and no default.
3. **Ask once, in one message, with options** (use AskUserQuestion with 2–4 concrete choices, recommended first). Never ask what you can verify in the code or the live sites.
4. **Restate the request as a checklist** in your head and tick each item in the final answer. People often send 5–10 asks in one message and mid-turn corrections; every item matters ("the arms should stay the same height" is a requirement, not a comment).
5. **Pasted text can be noise** (a stray terminal command, a leftover line). Ignore it and say so.
6. **Names:** "bloop" = the whale; "hologram"/"house" = the 3D shophouse; "dots" = service dots in a region; "detail page" = the pane that slides in; "the rail" = the sideways panels; "Goodlife" = the Seniors service; "the island floating" = the raised region.
7. **Visual feedback with an image** means: compare to the screenshot, fix exactly that, keep everything else.
8. Look for the unstated constraint: it must work on phone, with reduced motion, with no new libraries, and without breaking the tests.

## For the person writing prompts: a template that needs no follow-up
```
Where: <region / dot / hologram / Bloop / Mental Health page / Goodlife Studio page / header>
What should change: <the new behaviour or look, in one or two sentences>
When it happens: <hover / press / hold / on load / after 5 s>
Keep: <anything that must stay the same>
Look and feel: <colours, a reference site or image>
Done when: <what you will check>
```
Example: "Where: Bloop. What: after 5 seconds without moving the mouse he sleeps, eyes closed, head down, with floating zzz. When: idle. Keep: tricks and cursor following. Done when: moving the mouse wakes him with a small hop and he slowly follows again."

### Tips
- Say **where** you pressed or looked ("belly", "top-left back button", "the Seniors dot in the South"), not just what looked wrong.
- Give a picture or a URL for looks. Say what to copy from it ("the left-to-right scroll", not "the style").
- Put each wish on its own numbered line; mark corrections with "instead".
- Say if something is a **question** (no code change) or a **change**.
- Say "no need to explain" for things you do not want in the answer, such as preview steps.
- If you want a pause before moving on, say "wait for my merge" (this is the default).

## Prompts that work well
- "Make the Makan page's path animate in as you reach it."
- "Add a Goodlife At Home centre: <name>, <address>, <phone>, <email from the Contact Us page>."
- "Bloop should look at the Contact Us button whenever the page is on the contact panel."
- "Change the East region to the darkest teal; keep the dots."

## When to stop and report instead of building
A request that would show invented data, remove a feature the user liked, break the accessibility baseline, or needs a new dependency. Say why in one sentence and offer the closest safe option.
